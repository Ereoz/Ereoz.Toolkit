﻿namespace Ereoz.InstallerBase
{
    public enum InstallMode
    {
        Install,
        Update,
        Repair,
        None
    }
}
