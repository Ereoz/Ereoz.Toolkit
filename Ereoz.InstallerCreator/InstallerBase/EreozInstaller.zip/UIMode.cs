﻿namespace Ereoz.InstallerBase
{
    public enum UIMode
    {
        FullUI,
        StartWithConfigure,
        ProgressOnly,
        Silent
    }
}
